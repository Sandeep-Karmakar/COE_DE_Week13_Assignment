from databricks import dbutils  
from databricks.jobs import Job, JobRun, JobRunState  
from databricks.clusters import Cluster  
  
# Create 4 notebooks that read from a single table and insert/update data into 5 respective output Delta tables  
notebooks = []  
for i in range(4):  
  notebook = dbutils.notebooks.create(f"notebook_{i}", f"Read from single table and insert/update into Delta table {i}")  
  notebooks.append(notebook)  
  
# Create an orchestration notebook that calls the other notebooks using Dbutils  
orchestration_notebook = dbutils.notebooks.create("orchestration_notebook", "Orchestration notebook")  
orchestration_code = """  
%run./notebook_0  
%run./notebook_1  
%run./notebook_2  
%run./notebook_3  
"""  
dbutils.notebooks.write(orchestration_notebook, orchestration_code)  
  
# Create a parallel orchestration notebook that calls the 5 notebooks in parallel using concurrent notebook workflow  
parallel_orchestration_notebook = dbutils.notebooks.create("parallel_orchestration_notebook", "Parallel orchestration notebook")  
parallel_orchestration_code = """  
from concurrent.futures import ThreadPoolExecutor  
with ThreadPoolExecutor() as executor:  
  futures = []  
  for notebook in notebooks:  
   futures.append(executor.submit(dbutils.notebooks.run, notebook))  
  for future in futures:  
   future.result()  
"""  
dbutils.notebooks.write(parallel_orchestration_notebook, parallel_orchestration_code)  
  
# Create Jobs for both the notebooks using Databricks Jobs API  
job1 = Job(  
  name="Sequential Job",  
  existing_cluster_id="your_cluster_id",  
  notebook_task={  
   "notebook_id": orchestration_notebook  
  }  
)  
job1_id = job1.create()  
  
job2 = Job(  
  name="Parallel Job",  
  existing_cluster_id="your_cluster_id",  
  notebook_task={  
   "notebook_id": parallel_orchestration_notebook  
  }  
)  
job2_id = job2.create()  
  
# Schedule the jobs using Jobs API  
job1.schedule("0 0 12 * * *", "America/Los_Angeles")  
job2.schedule("0 0 12 * * *", "America/Los_Angeles")  
  
# Create similar compute cluster for both jobs using Clusters API  
cluster = Cluster(  
  cluster_name="your_cluster_name",  
  spark_version="7.3.x-scala2.12",  
  node_type_id="Standard_DS3_v2",  
  num_workers=2  
)  
cluster_id = cluster.create()  
  
# Compare runtime of sequential and parallel jobs  
job1_run = JobRun(job1_id)  
job2_run = JobRun(job2_id)  

while job1_run.state()!= JobRunState.SUCCESS or job2_run.state()!= JobRunState.SUCCESS:  
  time.sleep(10)  
  
print(f"Sequential job runtime: {job1_run.duration_ms} ms")  
print(f"Parallel job runtime: {job2_run.duration_ms} ms")